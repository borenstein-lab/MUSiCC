
=======
Authors
=======

MUSiCC is written and maintained by Ohad Manor and the Borenstein group in University of Washington