==================
Citing Information
==================

If you use the MUSiCC software, please cite the following paper:

MUSiCC: Towards an accurate estimation of average genomic copy-numbers in the human microbiome.
**Ohad Manor and Elhanan Borenstein.** *Submitted*